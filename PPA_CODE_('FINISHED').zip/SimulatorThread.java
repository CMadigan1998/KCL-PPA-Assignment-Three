
/**
 * Used when creating a new thread for the longRunSimulation method to run in so that the GUI components
 * can be updated in real-time rather than when the button action ends.
 *
 * @author Charlie Madigan(K19019003), Kacper Dudzinski (K1921541)
 * @version 2020.02.21
 */
public class SimulatorThread implements Runnable
{
    private Simulator sim;

    /**
     * Sets the Simulator objects.
     */
    public SimulatorThread(Simulator sim)
    {
        this.sim = sim;
    }

    /**
     * Runs the runLongSimulaton() method of Simulator.
     */
    public void run()
    {
        sim.runLongSimulation();
    } 
}
